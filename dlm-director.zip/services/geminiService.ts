import { GoogleGenAI, Type } from "@google/genai";
import { Scene, VideoCategory } from "../types";

// Helper to get AI instance (always fresh for key selection)
const getAi = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

// 1. Research / Trending
export const fetchTrendingTopics = async (category: VideoCategory): Promise<any[]> => {
  const ai = getAi();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Find 3 trending or popular video topics/styles suitable for a ${category} project right now. Provide a JSON response.`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
            }
          }
        }
      }
    });
    
    if (response.text) {
        return JSON.parse(response.text);
    }
    return [];
  } catch (error) {
    console.error("Error fetching trending:", error);
    return [{ title: "Error fetching trends", description: "Please try manual input." }];
  }
};

// 2. Script Generation
export const generateScript = async (
  category: string,
  style: string,
  prompt: string,
  sceneCount: number = 5
): Promise<Scene[]> => {
  const ai = getAi();
  const systemInstruction = `You are a world-class film director and screenwriter. 
  Create a visual script for a ${category} video. Style: ${style}.
  Break the story into exactly ${sceneCount} distinct scenes.
  For each scene, provide:
  1. A 'narration' (voiceover or dialogue line).
  2. A 'visualPrompt' (highly detailed, cinematic description for an image generator).
  3. A 'durationEstimate' (in seconds, typically 3-6s).
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              narration: { type: Type.STRING },
              visualPrompt: { type: Type.STRING },
              durationEstimate: { type: Type.INTEGER },
            },
            required: ['narration', 'visualPrompt', 'durationEstimate']
          }
        }
      }
    });

    const data = JSON.parse(response.text || '[]');
    // Enrich with IDs and status
    return data.map((item: any, index: number) => ({
      ...item,
      id: index + 1,
      status: 'pending'
    }));

  } catch (error) {
    console.error("Script generation error:", error);
    throw new Error("Failed to generate script.");
  }
};

// 3. Scene Image Generation (Nano Banana Pro / Gemini 3 Pro Image)
export const generateSceneImage = async (visualPrompt: string, aspectRatio: string): Promise<string> => {
  const ai = getAi();
  
  // Map our UI aspect ratios to Gemini API format if strictly needed, 
  // though gemini-3-pro-image-preview handles "16:9" strings well in imageConfig.
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: visualPrompt,
      config: {
        imageConfig: {
          aspectRatio: aspectRatio as any, // "16:9", "9:16", "1:1"
          imageSize: "2K" // High quality for cinematic feel
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData && part.inlineData.data) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data found in response");
  } catch (error) {
    console.error("Image gen error:", error);
    throw error;
  }
};

// 4. Video Generation (Veo 3)
export const generateSceneVideo = async (
  imageBase64: string, 
  prompt: string, 
  aspectRatio: string
): Promise<string> => {
  
  // Ensure we have a key selected for Veo
  if (window.aistudio && window.aistudio.hasSelectedApiKey) {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
          throw new Error("API_KEY_REQUIRED");
      }
  }

  // Create FRESH instance with current key
  const ai = getAi();

  // Veo expects raw base64 without data URI prefix for the image property
  const cleanBase64 = imageBase64.replace(/^data:image\/(png|jpeg|jpg);base64,/, '');

  try {
    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-generate-preview', // High quality Veo 3
      prompt: prompt, 
      image: {
        imageBytes: cleanBase64,
        mimeType: 'image/png', 
      },
      config: {
        numberOfVideos: 1,
        resolution: '1080p',
        aspectRatio: aspectRatio as any
      }
    });

    // Polling loop
    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000)); // Check every 5s
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!videoUri) throw new Error("Video generation failed: No URI returned.");

    // Fetch the actual binary to play locally
    const res = await fetch(`${videoUri}&key=${process.env.API_KEY}`);
    const blob = await res.blob();
    return URL.createObjectURL(blob);

  } catch (error) {
    console.error("Video gen error:", error);
    throw error;
  }
};
