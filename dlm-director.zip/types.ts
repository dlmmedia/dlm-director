export enum VideoCategory {
  CINEMATIC = 'Cinematic Trailer',
  YOUTUBE = 'YouTube Content',
  MUSIC_VIDEO = 'Music Video',
  COMMERCIAL = 'Commercial / Ad',
  DOCUMENTARY = 'Documentary',
  SHORTS = 'Vertical Short / Reel'
}

export enum AspectRatio {
  WIDESCREEN = '16:9',
  PORTRAIT = '9:16',
  SQUARE = '1:1',
  CINEMA = '21:9'
}

export interface VideoStyle {
  id: string;
  name: string;
  description: string;
}

export interface Scene {
  id: number;
  narration: string;
  visualPrompt: string;
  durationEstimate: number; // in seconds
  status: 'pending' | 'generating_image' | 'image_ready' | 'generating_video' | 'video_ready' | 'error';
  imageUrl?: string;
  videoUrl?: string;
  errorMsg?: string;
}

export interface ProjectConfig {
  title: string;
  category: VideoCategory;
  aspectRatio: AspectRatio;
  style: string;
  userPrompt: string;
  scenes: Scene[];
}

export interface TrendingTopic {
  title: string;
  description: string;
  url?: string;
}
