import React, { useState, useEffect, useRef } from 'react';
import { VideoCategory, AspectRatio, ProjectConfig, Scene, TrendingTopic } from './types';
import { generateScript, generateSceneImage, generateSceneVideo, fetchTrendingTopics } from './services/geminiService';
import { StepIndicator } from './components/StepIndicator';
import { VideoPlayer } from './components/VideoPlayer';

// --- SVGs ---
const FilmIcon = () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" /></svg>;
const MagicIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>;
const RefreshIcon = () => <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>;
const PlayIcon = () => <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" /></svg>;
const VideoIcon = () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>;

export default function App() {
  // State
  const [step, setStep] = useState(0);
  const [config, setConfig] = useState<ProjectConfig>({
    title: '',
    category: VideoCategory.CINEMATIC,
    aspectRatio: AspectRatio.WIDESCREEN,
    style: 'Realistic, Cinematic Lighting, 4K',
    userPrompt: '',
    scenes: []
  });
  
  const [trending, setTrending] = useState<TrendingTopic[]>([]);
  const [loadingScript, setLoadingScript] = useState(false);
  const [showPlayer, setShowPlayer] = useState(false);
  const [generatingAllVideos, setGeneratingAllVideos] = useState(false);
  const [researchLoading, setResearchLoading] = useState(false);

  // --- Handlers ---

  const handleFetchTrending = async () => {
    setResearchLoading(true);
    const data = await fetchTrendingTopics(config.category);
    setTrending(data);
    setResearchLoading(false);
  };

  const handleGenerateScript = async () => {
    if (!config.userPrompt) return;
    setLoadingScript(true);
    try {
      const scenes = await generateScript(config.category, config.style, config.userPrompt);
      setConfig(prev => ({ ...prev, scenes }));
      setStep(2); // Move to Script Review
    } catch (e) {
      alert("Failed to generate script. Please try again.");
    } finally {
      setLoadingScript(false);
    }
  };

  const handleGenerateImage = async (sceneId: number) => {
    setConfig(prev => ({
      ...prev,
      scenes: prev.scenes.map(s => s.id === sceneId ? { ...s, status: 'generating_image', errorMsg: undefined } : s)
    }));

    const scene = config.scenes.find(s => s.id === sceneId);
    if (!scene) return;

    try {
      // Add style context to the visual prompt
      const fullPrompt = `${config.style}. ${scene.visualPrompt}`;
      const imageUrl = await generateSceneImage(fullPrompt, config.aspectRatio);
      
      setConfig(prev => ({
        ...prev,
        scenes: prev.scenes.map(s => s.id === sceneId ? { 
          ...s, 
          status: 'image_ready', 
          imageUrl 
        } : s)
      }));
    } catch (e) {
      setConfig(prev => ({
        ...prev,
        scenes: prev.scenes.map(s => s.id === sceneId ? { ...s, status: 'error', errorMsg: 'Image gen failed' } : s)
      }));
    }
  };

  const handleGenerateVideo = async (sceneId: number) => {
    // Check for API key first
    try {
        if (window.aistudio && window.aistudio.hasSelectedApiKey) {
            const hasKey = await window.aistudio.hasSelectedApiKey();
            if (!hasKey) {
                await window.aistudio.openSelectKey();
            }
        }
    } catch (e) {
        console.error("API Key selection error", e);
        return;
    }

    setConfig(prev => ({
      ...prev,
      scenes: prev.scenes.map(s => s.id === sceneId ? { ...s, status: 'generating_video', errorMsg: undefined } : s)
    }));

    const scene = config.scenes.find(s => s.id === sceneId);
    if (!scene || !scene.imageUrl) return;

    try {
      const videoUrl = await generateSceneVideo(scene.imageUrl, scene.visualPrompt, config.aspectRatio);
      
      setConfig(prev => ({
        ...prev,
        scenes: prev.scenes.map(s => s.id === sceneId ? { 
          ...s, 
          status: 'video_ready', 
          videoUrl 
        } : s)
      }));
    } catch (e: any) {
        let errorMsg = 'Video gen failed';
        if (e.message === 'API_KEY_REQUIRED') {
            errorMsg = "API Key Required for Veo";
        }
        setConfig(prev => ({
            ...prev,
            scenes: prev.scenes.map(s => s.id === sceneId ? { ...s, status: 'error', errorMsg } : s)
        }));
    }
  };

  const generateAllImages = async () => {
    for (const scene of config.scenes) {
      if (scene.status === 'pending' || scene.status === 'error') {
        await handleGenerateImage(scene.id);
      }
    }
  };

  const generateAllVideos = async () => {
    // Ensure Key first
    try {
         if (window.aistudio) {
             const hasKey = await window.aistudio.hasSelectedApiKey();
             if (!hasKey) await window.aistudio.openSelectKey();
         }
    } catch(e) { return; }

    setGeneratingAllVideos(true);
    // Process strictly sequentially to avoid hitting rate limits too hard, 
    // although parallel is possible with higher quota. Let's do batch of 1 for safety in demo.
    for (const scene of config.scenes) {
      if ((scene.status === 'image_ready' || scene.status === 'video_ready') && !scene.videoUrl) {
         await handleGenerateVideo(scene.id);
      }
    }
    setGeneratingAllVideos(false);
  };

  // --- Views ---

  // STEP 0: CONCEPT
  const renderConceptStep = () => (
    <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-serif text-white tracking-tight">DLM Director <span className="text-dlm-accent">.</span></h1>
        <p className="text-xl text-gray-400">Elite Cinematic Video Generation</p>
      </div>

      {/* Categories */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {Object.values(VideoCategory).map((cat) => (
          <button
            key={cat}
            onClick={() => setConfig({ ...config, category: cat })}
            className={`p-6 rounded-xl border transition-all duration-300 text-left group ${
              config.category === cat 
                ? 'border-dlm-accent bg-dlm-800 shadow-[0_0_20px_rgba(212,175,55,0.1)]' 
                : 'border-dlm-700 bg-dlm-900 hover:border-dlm-secondary/50'
            }`}
          >
            <div className={`mb-3 ${config.category === cat ? 'text-dlm-accent' : 'text-gray-500'}`}>
              <FilmIcon />
            </div>
            <h3 className="text-lg font-medium text-white">{cat}</h3>
            <p className="text-sm text-gray-500 mt-1">AI Optimized Workflow</p>
          </button>
        ))}
      </div>

      {/* Trending / Research */}
      <div className="bg-dlm-800 rounded-xl p-6 border border-dlm-700">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-medium text-white flex items-center gap-2">
            <span className="text-dlm-secondary">●</span> Market Research
          </h2>
          <button 
            onClick={handleFetchTrending} 
            disabled={researchLoading}
            className="text-sm text-dlm-accent hover:text-white flex items-center gap-1 disabled:opacity-50"
          >
            <RefreshIcon /> {researchLoading ? 'Analyzing...' : 'Analyze Trends'}
          </button>
        </div>
        {trending.length > 0 ? (
          <div className="grid md:grid-cols-3 gap-4">
            {trending.map((t, i) => (
              <div key={i} className="bg-dlm-900 p-4 rounded-lg border border-dlm-700 hover:border-dlm-secondary cursor-pointer transition-colors"
                   onClick={() => setConfig({...config, userPrompt: `Create a video about: ${t.title}. ${t.description}`})}>
                <h4 className="text-white font-medium mb-1 truncate">{t.title}</h4>
                <p className="text-xs text-gray-400 line-clamp-2">{t.description}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500 text-sm italic">Analyze market trends to get data-driven inspiration for your {config.category}.</p>
        )}
      </div>

      <div className="flex justify-end pt-4">
        <button 
          onClick={() => setStep(1)}
          className="px-8 py-3 bg-white text-black font-bold rounded-lg hover:bg-gray-200 transition-colors"
        >
          Next: Configuration &rarr;
        </button>
      </div>
    </div>
  );

  // STEP 1: CONFIGURATION
  const renderConfigStep = () => (
    <div className="max-w-3xl mx-auto space-y-6">
      <h2 className="text-3xl font-serif text-white mb-6">Project Configuration</h2>
      
      <div className="grid grid-cols-2 gap-6">
        <div>
          <label className="block text-gray-400 text-sm mb-2">Aspect Ratio</label>
          <select 
            value={config.aspectRatio}
            onChange={(e) => setConfig({...config, aspectRatio: e.target.value as AspectRatio})}
            className="w-full bg-dlm-900 border border-dlm-700 rounded-lg p-3 text-white focus:border-dlm-accent outline-none"
          >
            {Object.values(AspectRatio).map(r => <option key={r} value={r}>{r}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-gray-400 text-sm mb-2">Visual Style</label>
          <select 
            value={config.style}
            onChange={(e) => setConfig({...config, style: e.target.value})}
            className="w-full bg-dlm-900 border border-dlm-700 rounded-lg p-3 text-white focus:border-dlm-accent outline-none"
          >
             <option>Realistic, Cinematic Lighting, 4K</option>
             <option>Cyberpunk, Neon, High Contrast</option>
             <option>Anime Style, Studio Ghibli inspired</option>
             <option>Vintage 35mm Film Grain</option>
             <option>Minimalist, Corporate Memphis</option>
             <option>Dark Fantasy, Detailed Texture</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-gray-400 text-sm mb-2">Creative Prompt</label>
        <textarea 
          value={config.userPrompt}
          onChange={(e) => setConfig({...config, userPrompt: e.target.value})}
          placeholder="Describe your video idea in detail..."
          className="w-full h-32 bg-dlm-900 border border-dlm-700 rounded-lg p-4 text-white focus:border-dlm-accent outline-none resize-none"
        />
        <div className="flex justify-between mt-2">
            <span className="text-xs text-gray-500">AI will auto-script based on this prompt.</span>
        </div>
      </div>

      <div className="flex justify-between pt-6">
        <button onClick={() => setStep(0)} className="text-gray-400 hover:text-white">Back</button>
        <button 
          onClick={handleGenerateScript}
          disabled={loadingScript || !config.userPrompt}
          className="px-8 py-3 bg-dlm-accent text-black font-bold rounded-lg hover:bg-dlm-accentHover disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
        >
          {loadingScript ? (
            <>
              <svg className="animate-spin h-5 w-5 text-black" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating Script...
            </>
          ) : (
            <>
              <MagicIcon /> Generate Script
            </>
          )}
        </button>
      </div>
    </div>
  );

  // STEP 2: SCRIPT REVIEW
  const renderScriptStep = () => (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-serif text-white">Script Review</h2>
        <span className="text-dlm-accent text-sm font-medium">{config.scenes.length} Scenes Generated</span>
      </div>

      <div className="space-y-4">
        {config.scenes.map((scene, idx) => (
          <div key={scene.id} className="bg-dlm-800 p-5 rounded-lg border border-dlm-700 hover:border-dlm-600 transition-colors">
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-full bg-dlm-900 flex items-center justify-center text-gray-400 font-bold text-sm shrink-0">
                {idx + 1}
              </div>
              <div className="flex-1 space-y-3">
                <div>
                  <label className="text-xs text-dlm-secondary uppercase tracking-wider font-semibold">Narration</label>
                  <p className="text-gray-300 mt-1">{scene.narration}</p>
                </div>
                <div>
                  <label className="text-xs text-dlm-accent uppercase tracking-wider font-semibold">Visual Prompt</label>
                  <textarea 
                    value={scene.visualPrompt}
                    onChange={(e) => {
                       const newScenes = [...config.scenes];
                       newScenes[idx].visualPrompt = e.target.value;
                       setConfig({...config, scenes: newScenes});
                    }}
                    className="w-full mt-1 bg-dlm-900/50 text-gray-300 text-sm p-2 rounded border border-transparent focus:border-dlm-accent outline-none"
                    rows={2}
                  />
                </div>
              </div>
              <div className="text-right shrink-0">
                <span className="text-xs text-gray-500 block">{scene.durationEstimate}s</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-between pt-6">
        <button onClick={() => setStep(1)} className="text-gray-400 hover:text-white">Back</button>
        <button 
          onClick={() => { setStep(3); generateAllImages(); }}
          className="px-8 py-3 bg-white text-black font-bold rounded-lg hover:bg-gray-200 transition-colors"
        >
          Approve & Generate Storyboard &rarr;
        </button>
      </div>
    </div>
  );

  // STEP 3: STORYBOARD & PRODUCTION
  const renderStoryboardStep = () => (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex justify-between items-end">
        <div>
           <h2 className="text-3xl font-serif text-white mb-2">Production Studio</h2>
           <p className="text-gray-400 text-sm">Review scenes (Nano Banana Pro) and render final clips (Veo 3).</p>
        </div>
        <div className="flex gap-3">
            <button 
                onClick={generateAllVideos}
                disabled={generatingAllVideos}
                className="px-6 py-2 bg-dlm-accent text-black font-bold rounded hover:bg-dlm-accentHover disabled:opacity-50 flex items-center gap-2"
            >
                {generatingAllVideos ? 'Rendering Queue...' : 'Render All Videos'} <VideoIcon />
            </button>
            <button 
                onClick={() => setShowPlayer(true)}
                className="px-6 py-2 bg-blue-600 text-white font-bold rounded hover:bg-blue-500 flex items-center gap-2"
            >
                Watch Full Movie <PlayIcon />
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {config.scenes.map((scene) => (
          <div key={scene.id} className="bg-dlm-800 rounded-xl overflow-hidden border border-dlm-700 group relative">
            {/* Status Badge */}
            <div className="absolute top-2 left-2 z-10 px-2 py-1 rounded bg-black/60 backdrop-blur text-xs font-mono text-white">
              {scene.status === 'pending' && 'PENDING'}
              {scene.status === 'generating_image' && <span className="text-yellow-400 animate-pulse">GEN IMG...</span>}
              {scene.status === 'image_ready' && <span className="text-blue-400">IMG READY</span>}
              {scene.status === 'generating_video' && <span className="text-purple-400 animate-pulse">RENDERING VEO...</span>}
              {scene.status === 'video_ready' && <span className="text-green-400">COMPLETE</span>}
              {scene.status === 'error' && <span className="text-red-500">ERROR</span>}
            </div>

            {/* Main Visual Area */}
            <div className="aspect-video bg-black relative flex items-center justify-center">
              {scene.imageUrl ? (
                <>
                    <img src={scene.imageUrl} alt={`Scene ${scene.id}`} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                    {scene.videoUrl && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/50 group-hover:bg-transparent transition-all">
                             <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur flex items-center justify-center text-white">
                                <PlayIcon />
                             </div>
                        </div>
                    )}
                </>
              ) : (
                <div className="text-gray-700">
                    {scene.status === 'generating_image' ? (
                        <div className="w-8 h-8 border-2 border-dlm-accent border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                        <span className="text-xs">No Image</span>
                    )}
                </div>
              )}
            </div>

            {/* Controls */}
            <div className="p-4 space-y-3">
              <p className="text-gray-300 text-xs line-clamp-2 h-8">{scene.narration}</p>
              
              <div className="flex gap-2 mt-4">
                <button 
                  onClick={() => handleGenerateImage(scene.id)}
                  className="flex-1 py-2 text-xs border border-dlm-600 text-gray-300 hover:text-white hover:border-gray-400 rounded transition-colors"
                >
                  Regenerate Image
                </button>
                <button 
                  onClick={() => handleGenerateVideo(scene.id)}
                  disabled={!scene.imageUrl || scene.status === 'generating_video'}
                  className={`flex-1 py-2 text-xs font-bold rounded transition-colors ${
                    scene.videoUrl 
                      ? 'bg-green-900/30 text-green-400 border border-green-800'
                      : 'bg-dlm-accent text-black hover:bg-dlm-accentHover'
                  } disabled:opacity-20`}
                >
                  {scene.videoUrl ? 'Re-Render Video' : 'Veo Render'}
                </button>
              </div>
              {scene.errorMsg && <p className="text-red-500 text-xs mt-1">{scene.errorMsg}</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-dlm-accent selection:text-black pb-20">
      {/* Header */}
      <header className="border-b border-dlm-800 bg-[#050505]/80 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-dlm-accent to-yellow-700 rounded-lg flex items-center justify-center text-black font-bold font-serif">D</div>
            <span className="font-serif font-bold tracking-wide">DLM Director</span>
          </div>
          <div className="text-xs text-gray-500 font-mono">
            {config.title || 'Untitled Project'}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-10">
        <StepIndicator currentStep={step} />
        
        <div className="mt-10">
          {step === 0 && renderConceptStep()}
          {step === 1 && renderConfigStep()}
          {step === 2 && renderScriptStep()}
          {step === 3 && renderStoryboardStep()}
        </div>
      </main>

      {/* Global Modals */}
      {showPlayer && (
        <VideoPlayer scenes={config.scenes} onClose={() => setShowPlayer(false)} />
      )}
    </div>
  );
}
