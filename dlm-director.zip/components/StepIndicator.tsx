import React from 'react';

interface Props {
  currentStep: number;
}

const steps = ['Concept', 'Script', 'Storyboard', 'Production'];

export const StepIndicator: React.FC<Props> = ({ currentStep }) => {
  return (
    <div className="flex items-center justify-center w-full mb-8">
      {steps.map((label, idx) => (
        <div key={label} className="flex items-center">
          <div className={`flex flex-col items-center relative`}>
            <div 
              className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                idx <= currentStep 
                  ? 'bg-dlm-accent text-black shadow-[0_0_10px_rgba(212,175,55,0.5)]' 
                  : 'bg-dlm-700 text-gray-500'
              }`}
            >
              {idx + 1}
            </div>
            <span className={`absolute -bottom-6 text-xs font-medium uppercase tracking-widest ${
              idx <= currentStep ? 'text-dlm-accent' : 'text-gray-600'
            }`}>
              {label}
            </span>
          </div>
          {idx < steps.length - 1 && (
            <div className={`w-16 h-0.5 mx-2 transition-colors duration-300 ${
              idx < currentStep ? 'bg-dlm-accent' : 'bg-dlm-700'
            }`} />
          )}
        </div>
      ))}
    </div>
  );
};
