import React, { useState, useEffect, useRef } from 'react';
import { Scene } from '../types';

interface Props {
  scenes: Scene[];
  onClose: () => void;
}

export const VideoPlayer: React.FC<Props> = ({ scenes, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  // Filter only ready scenes with valid video URLs
  const playableScenes = scenes.filter(s => s.status === 'video_ready' && s.videoUrl);

  useEffect(() => {
    if (videoRef.current && playableScenes[currentIndex]) {
      videoRef.current.src = playableScenes[currentIndex].videoUrl!;
      videoRef.current.play().then(() => setIsPlaying(true)).catch(e => console.error(e));
    }
  }, [currentIndex, playableScenes]);

  const handleEnded = () => {
    if (currentIndex < playableScenes.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      setIsPlaying(false);
    }
  };

  if (playableScenes.length === 0) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md">
      <div className="relative w-full max-w-5xl aspect-video bg-black shadow-2xl border border-dlm-700 rounded-lg overflow-hidden">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 text-white/50 hover:text-white transition-colors"
        >
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          controls
          onEnded={handleEnded}
        />

        <div className="absolute bottom-8 left-8 right-8 pointer-events-none">
          <div className="text-white/80 text-lg font-serif drop-shadow-md">
            Scene {currentIndex + 1} / {playableScenes.length}
          </div>
          <p className="text-white/60 text-sm mt-1 drop-shadow-md max-w-3xl">
            {playableScenes[currentIndex]?.narration}
          </p>
        </div>
      </div>
    </div>
  );
};
